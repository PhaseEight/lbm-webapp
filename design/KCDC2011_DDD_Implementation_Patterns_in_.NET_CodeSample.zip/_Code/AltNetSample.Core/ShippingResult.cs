
namespace AltNetSample.Domain
{
    public enum ShippingResult
    {
        Success,
        Failure,
        Delayed,
        Cancelled
    }
}
