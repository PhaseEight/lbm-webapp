
namespace AltNetSample.Domain
{
    public enum OrderStatus
    {
        Open, Closed, Cancelled
    }
}
